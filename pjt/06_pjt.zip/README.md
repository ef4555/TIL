>  PJT 작성 시 주의!
> 
> * 절대로 코드만 복붙하지 않는다.
> * 후기는 적어도 3줄은 씁시다!
> * 교수님이 안 볼 것 같지만 다 뜯어 봅니다.
> * 제출 당일 23:59분 내로 제출 합시다!
> * readme 없으면 일주일간 박제할 예정입니다. 
>   * 물론 readme 작성도 결국 해주셔야 합니다. 

# 

# PJT 01

### 이번 pjt 를 통해 배운 내용

* github를 이용한 협업 체험

* 게시판의 CRUD 구현과 M:N 관계의 테이블 구성

* 중계 테이블 설정과 자기참조 테이블 설정

* ....

## A. base.html

* 로그인 상태 
  - 회원정보수정
  - 로그아웃
  - 회원탈퇴
  - 내 프로필

* 결과 : 
  
  ```html
  <body>
  <div class="container">
    <div id="nav">
      {% if user.is_authenticated %}
      <h3 id="user-hello">Hello, {{user}}</h3>
        <a href="{% url 'accounts:update' %}">회원정보수정</a>
        <form action="{% url 'accounts:logout' %}"method='POST'>
          {% csrf_token %}
          <input type="submit" value="로그아웃">
        </form>
        <form action="{% url 'accounts:delete' %}" method="POST">
          {% csrf_token %}
          <input type="submit" value="회원탈퇴">
        </form>
        <a href="{% url 'accounts:profile' user.username %}">내 프로필</a>        
      {% else %}
        <a href="{% url 'accounts:login' %}">Login</a>
        <a href="{% url 'accounts:signup' %}">Signup</a>       
      {% endif %}
    </div>
  ```

  ```python
  def profile(request, username):
    User = get_user_model()
    person = User.objects.get(username=username)
    context = {
        'person':person,
    }
    return render(request, 'accounts/profile.html', context)
  ```
  
  * 이 문제에서 어려웠던점
    - 경로 설정
    - 로그인 구현, 프로필 페이지 설정하고 테이블 설정하기

  * 내가 생각하는 이 문제의 포인트
    - User모델 설정하고 views.py에서 테이블에서 정보 불러와서 base.html전달하기

-----

## B. index.html

* 전체 영화 목록 조회 페이지
  - 데이터베이스에 존재하는 모든 영화의 목록 표시
  - 영화 제목 표시하고 클릭 시 상세 조회 페이지로 이동
  - 좋아요 기능을 구현하고 좋아요 클릭시 좋아요 취소로 변경되고 좋아요 취소 누를 시 좋아요로 변경되는 버튼 생성

* 결과 : 
  
  ```html
  {% for movie in movies %}
  {% if movie.thumbnail_img %}
    <img src="{{ movie.thumbnail_img.url }}" alt="{{ movie.thumbnail_img }}">
  {% endif %}
  <a class="" href="{% url 'movies:detail' movie.pk %}">{{ movie.title }}</a>
  <br>
  작성자: <a class="" href="{% url 'accounts:profile' movie.user.username %}"> {{movie.user}}</a>
  <br>
  <span>좋아요 : {{movie.like_users.count}}</span>
  {% if request.user.is_authenticated %}
  <form action="{% url 'movies:likes' movie.pk %}" method="POST">
    {% csrf_token %}
    {% if request.user in movie.like_users.all %}
      <input type="submit" value="좋아요 취소">
    {% else %}
      <input type="submit" value="좋아요">
    {% endif %}
  </form>
  ```

  ```python
  def index(request):
      movies = Movie.objects.all()[::-1]
      hashtag = Active_hashtag.objects.all().distinct().values_list('hashtag')
      hash = []
      for i in hashtag:
          hash.append(Hashtag.objects.filter(pk=i[0]))
      context = {
          'movies': movies,
          'hash': hash,
      }
      return render(request, 'movies/index.html', context)

  def likes(request, movie_pk):
    if request.user.is_authenticated:
        movie = Movie.objects.get(pk=movie_pk)
        if movie.like_users.filter(pk=request.user.pk).exists():
            movie.like_users.remove(request.user)
        else:
            movie.like_users.add(request.user)
        return redirect('movies:detail', movie_pk)
    return redirect('accounts:login')
  ```
  
  * 이 문제에서 어려웠던점
    - 경로 설정
    - movie테이블에 M:N 관계 설정하기

  * 내가 생각하는 이 문제의 포인트
    - Movie 모델에서 like_users = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='like_movies')설정하고 정보 불러오기

-----


## C. detail.html

* 영화 상세 정보 페이지
  - 특정 영화의 상세 정보를 표시
  - 댓글을 작성할 수 있는 폼 표시
  - 댓글 삭제 버튼은 댓글 작성자에게만 표시
  - 해당 영화의 수정 및 삭제 버튼을 표시
  - 전체 영화 목록 조회 페이지로 이동하는 링크를 표시

* 결과 : 
  
  ```html
  <h1>DETAIL</h1>
  <hr>
  {% if movie.image %}
    <img src="{{movie.image.url}}" />
  {% endif %}
  <div>
    <h5>{{ movie.title }}</h5>
    <span>좋아요 : {{movie.like_users.count}}</span>
    <hr>    
    <p>{{ movie.description }}</p>
  </div>
  <hr>

  {% if request.user == movie.user %}
      <a href="{% url 'movies:update' movie.pk %}">UPDATE</a>
      <form action="{% url 'movies:delete' movie.pk %}" id="delete-form">
        {% csrf_token %}
        <input type="submit" value="DELETE" id="delete-btn" />
      </form>
  {% endif %}
  <a href="{% url 'movies:index' %}">BACK</a>
  <hr>
  <h5>댓글 목록</h5>
  {% if comments %}
      <p><b>{{comments|length}}개의 댓글</b></p>
  {% endif %}
  <ul>  
    {% for comment in comments %}     
      <li>
        {{comment.user}} : {{comment.content}} 
        {% if request.user == comment.user %}
        <form action="{% url 'movies:comments_delete' movie.pk comment.pk %}" method="POST">
          {% csrf_token %}
          <input type="submit" value="삭제">
        </form>
        {% endif %}
      </li>
      <p>대댓글</p>
        {% for reply in comment.replies.all %}
        <p>{{ reply.content }}</p>
        {% endfor %}
        <form action="{% url 'movies:comments_create' movie.pk %}" method="POST">
          <input type="hidden" name="parent_pk" value="{{ comment.pk }}">
          {% csrf_token %}
          {{ comment_form }}
          <input type="submit" value="대댓글">
        </form>
      {% empty %}
        <li>댓글이 없습니다 :(</li>
    {% endfor %}
  </ul>
  {% if request.user.is_authenticated %}
    <form action="{% url 'movies:comments_create' movie.pk %}" method="POST">
      {% csrf_token %}
      {{comment_form}}
      <input type="submit" value="저장">
    </form>
    {% else %}
      <a href="{% url 'accounts:login' %}">[댓글을 작성하려면 로그인하세요.]</a>
  {% endif %}
  {% endblock  %}

  ```

  ```python
  def detail(request, pk):
    movie = Movie.objects.get(pk=pk)
    comment_form = CommentForm()
    comments = movie.comment_set.all()
    # Select * from comment where parent is NULL;
    comments = movie.comment_set.filter(parent__isnull=True) # 대댓글
    context = {
        'movie': movie,
        'comment_form': comment_form,
        'comments': comments,
    }
    return render(request, 'movies/detail.html', context)
  ```
  
  * 이 문제에서 어려웠던점
    - 경로 설정
    - Comment테이블 설정하고 ModelForm 만들어서 댓글 기능 구현하기

  * 내가 생각하는 이 문제의 포인트
    - Comment테이블 설정하고 ModelForm 만들어서 댓글 기능 구현하기

-----

## D. create.html

* 영화 생성 페이지
  - 특정 영화를 생성하기 위한 HTML form요소를 표시
  - 표시되는 form은 Movie 모델 클래스에 기반한 ModelForm이어야한다
  - 작성한 정보는 제출 시 단일 영화 정보를 저장하는 URL로 요청과 함께 전송
  - 전체 영화 목록 조회 페이지로 이동하는 링크를 표시

* 결과 : 
  
  ```html
  {% extends 'base.html' %}

  {% block content %}
    <h1>CREATE</h1>
    <hr>
    <form action="{% url 'movies:create' %}" method="POST" enctype='multipart/form-data'>
      {% csrf_token %}
      {{ form.as_p }}
      <button type="submit">Submit</button>
    </form>
    <hr>
    <a href="{% url 'movies:index' %}">BACK</a>
  {% endblock %}


  ```

  ```python
  @require_http_methods(['POST','GET'])
  def create(request):
      if request.method == 'POST':
          form = MovieForm(request.POST, request.FILES)
          if form.is_valid():
              movie = form.save(commit=False)
              movie.user = request.user
              movie.save()
              # hash tag 저장
              for word in movie.description.split(): # 공백을 기준으로 리스트
                  if word[0] == '#':
                      # word랑 같은 해시태그가 존재하면 기존 객체 반환, 없으면 새로운 객체 생성
                      hashtag, created = Hashtag.objects.get_or_create(content=word)
                      # 1. 현재 등록된 모든 해시태그 보기
                      # 2. 클릭 시 hashtag 기준으로 filter 해주기
                      # 3. 게시물 수정 시, 새로 등록된 해시태그 검사 해주기                      
                      movie.hashtags.add(hashtag)
              return redirect('movies:detail', movie.pk)
      else:
          form = MovieForm()
          hash = Hashtag.objects.all()

      context = {
          'form': form,
          'hash': hash,
      }
      return render(request, 'movies/create.html', context)
  ```
  
  * 이 문제에서 어려웠던점
    - 경로 설정
    - ModelForm 만들어서 글 작성 기능 구현하기

  * 내가 생각하는 이 문제의 포인트
    - ModelForm 만들어서 글 작성 기능 구현하기

-----

## E. create.html

* 영화 수정 페이지

* 결과 : 
  
  ```html
  <h1>UPDATE</h1>
  <hr>
  <form action="{% url 'movies:update' movie.pk %}" method="POST"  enctype='multipart/form-data'>
    {% csrf_token %} {{form.as_p}}
    <input type="submit" />
  </form>
  <hr>
  <a href="{% url 'movies:detail' movie.pk %}">BACK</a>
  ```

  ```python
  def update(request, pk):
      movie = Movie.objects.get(pk=pk)
      if request.method == 'POST':
          form = MovieForm(request.POST, request.FILES, instance=movie)
          if form.is_valid():
              form.save()
              return redirect('movies:detail', movie.pk)
      else:
          form = MovieForm(instance=movie)
      context = {
          'movie': movie,
          'form': form,
      }
      return render(request, 'movies/update.html', context)

  ```
  
  * 이 문제에서 어려웠던점
    - 경로 설정
    - ModelForm 만들어서 글 수정 구현하기

  * 내가 생각하는 이 문제의 포인트
    - ModelForm 만들어서 글 수정 구현하기

-----

## F. login.html

* 로그인 페이지

* 결과 : 
  
  ```html
  {% extends 'base.html' %}

  {% block content %}
    <h1>Login</h1>
    <form action="{% url 'accounts:login' %}" method="POST">
      {% csrf_token %}
      {{form.as_p}}
      <input type="submit" value="로그인">
    </form>
  {% endblock content %}
  ```
  
  ```python
  @require_http_methods(['POST','GET'])
  def login(request):
      if request.method == 'POST':
          form = AuthenticationForm(request, request.POST)
          if form.is_valid():
              auth_login(request, form.get_user())
              return redirect('movies:index')
      else:
          form = AuthenticationForm()

      context = {'form': form}
      return render(request, 'accounts/login.html', context)

  ```
  
  * 이 문제에서 어려웠던점
    - 경로 설정
    - Django login 사용하기

  * 내가 생각하는 이 문제의 포인트
    - Django login 사용하기

-----
## G. Signup.html

* 회원가입 페이지

* 결과 : 
  
  ```html
  {% extends 'base.html' %}

  {% block content %}
    <h1>회원가입</h1>
    <form action="{% url 'accounts:signup' %}" method="POST">
      {% csrf_token %}
      {{form.as_p}}
      <input type="submit" value="회원가입">
    </form>
    <a href="{% url 'movies:index' %}">목록보기</a>
  {% endblock content %}
  ```
  ```python
  @require_http_methods(['POST','GET'])
  def signup(request):
      if request.method == 'POST':
          form = CustomUserCreationForm(request.POST)
          if form.is_valid():
              user = form.save()
              auth_login(request, user)
              return redirect('movies:index') 
      else:
          form = CustomUserCreationForm()
      context = {'form': form}
      return render(request, 'accounts/signup.html', context)
```
  * 이 문제에서 어려웠던점
    - 경로 설정
    - Django CustomUserCreationForm 사용하기

  * 내가 생각하는 이 문제의 포인트
    - Django CustomUserCreationForm 설정 후 사용하기

-----

## H. Update.html

* 회원정보수정 페이지

* 결과 : 
  
  ```html
  {% extends 'base.html' %}

  {% block content %}
    <h1>회원정보수정</h1>
    <form action="{% url 'accounts:update' %}" method="POST">
      {% csrf_token %}
      {{form.as_p}} 
      <input type="submit" value="수정하기">
    </form>
    <a href="{% url 'movies:index' %}">목록보기</a>
  {% endblock content %}
  ```

  ```python
    @require_http_methods(['POST','GET'])
    def update(request):
        if request.method == 'POST':
            form = CustomUserChangeForm(request.POST, instance=request.user)
            if form.is_valid():
                form.save()
                return redirect('movies:index') 
        else:
            form = CustomUserChangeForm(instance=request.user)
        context = {'form': form}
        return render(request, 'accounts/update.html', context)
  ```
  * 이 문제에서 어려웠던점
    - 경로 설정
    - Django CustomUserChangeForm 사용하기

  * 내가 생각하는 이 문제의 포인트
    - Django CustomUserChangeForm 설정 후 사용하기

-----

## I. change_password.html

* 비밀번호 변경 페이지

* 결과 : 
  
  ```html
  {% extends 'base.html' %}

  {% block content %}
    <h1>비밀번호변경</h1>
    <form action="{% url 'accounts:change_password' %}" method="POST">
      {% csrf_token %}
      {{form.as_p}}
      <input type="submit" value="변경하기">
    </form>
    <a href="{% url 'movies:index' %}">목록보기</a>
  {% endblock content %}

  ```

  ```python
  @require_http_methods(['POST','GET'])
  def change_password(request):
      if request.method == 'POST':
          form = PasswordChangeForm(request.user, request.POST)
          if form.is_valid():
              form.save()
              update_session_auth_hash(request, form.user)
              return redirect('movies:index') 
      else:
          form = PasswordChangeForm(request.user)
      context = {'form': form}
      return render(request, 'accounts/change_password.html', context)
  ```

  * 이 문제에서 어려웠던점
    - 경로 설정
    - Django PasswordChangeForm 사용하기

  * 내가 생각하는 이 문제의 포인트
    - Django PasswordChangeForm설정 후 사용하기

-----


# 후기

* github를 이용한 협업을 처음 체험해보았다. 각자 부분을 나누어 일을 진행할 수 있었다.
* 각자 포크한 작업소에서 작업하고 branch를 나누어 작업하는 이유에 대해 느낄 수 있었다. 
* 충돌이 일어나지 않게 각자 맡을 부분을 정확히 정해야 하는 것이 어려웠다. 
* 그리고 한 기능에 다른 기능이 필요할 때가 많아서 주기적으로 pull을 받으면서 작업을 진행해야 했다. 
* 과제 자체는 저번 주에 한 내용이라 어렵지 않았고 협업하는 과정이 어려웠다. 
